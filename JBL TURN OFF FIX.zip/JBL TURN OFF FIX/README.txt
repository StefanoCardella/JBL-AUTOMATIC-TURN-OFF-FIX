
To run the script at computer startup:

1. Open the Windows "Run" dialog using the "Win+R" key combination.
2. Enter the command "shell:startup" and press Enter.
3. This command will open the Startup folder:
4. Copy the file "main.exe" into this folder and then restart your computer.
5. From this point on, you won't need to manually start the script every time you boot your PC.

:)